from django.apps import AppConfig


class PatternLibraryAppConfig(AppConfig):
    name = 'pattern_library'
    default_auto_field = 'django.db.models.AutoField'
